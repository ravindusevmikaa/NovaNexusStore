<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile Settings</title>
    <link href="../assets/css/style.css" rel="stylesheet">
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
 <style>
    .btn-custom {
    background-color: maroon;
    color: #fff;
    border: none;
}

 </style>
</head>

<body>
    <div class="container mt-5">
        <div class="row">
            <div class="col-md-4">
                <div class="sidebar">
                <div class="text-center mb-4">
                        <img src="../assets/img/avt.jpg" class="profile-pic" alt="Profile Picture">
                        <div class="mt-2">
                            <button class="btn btn-outline-secondary">Upload a New Photo</button>
                        </div>
                    </div>
                    <div class="form-group">
                            <label for="address">Address</label>
                            <input type="text" class="form-control mb-2" id="address" placeholder="Street Address">
                            <input type="text" class="form-control mb-2" placeholder="City">
                            <input type="text" class="form-control mb-2" placeholder="State/Province">
                            <input type="text" class="form-control mb-2" placeholder="Zip Code">
                            <select class="form-control">
                            <option>Select your country</option>
                               <option value="Finland">Finland</option>
                                <option value="France">France</option>
                                <option value="Germany">Germany</option>
                                <option value="India">India</option>
                                <option value="Japan">Japan</option>
                                <option value="Kuwait">Kuwait</option>
                                <option value="Maldives">Maldives</option>
                                <option value="Nepal">Nepal</option>
                                <option value="Oman">Oman</option>
                                <option value="Pakistan">Pakistan</option>
                                <option value="Qatar">Qatar</option>
                                <option value="Romania">Romania</option>
                                <option value="Sri Lanka">Sri Lanka</option>
                                <option value="Thailand">Thailand</option>
                                <option value="UK">UK</option>   
                                <option value="Afghanistan">Afghanistan</option>
                                <option value="Albania">Albania</option>
                                <option value="Algeria">Algeria</option>
                                <option value="Andorra">Andorra</option>
                                <option value="Angola">Angola</option>
                                <option value="Austria">Austria</option>
                                <option value="Canada">Canada</option>
                                <option value="Denmark">Denmark</option>
                                <option value="Egypt">Egypt</option>
                                <option value="Ethiopia">Ethiopia</option>
                             
                            </select>
                        </div>

                </div>
            </div>
            <div class="col-md-8">
                <div class="profile-form">
                   

                    <form>
                        <div class="form-group">
                            <label for="fullName">Full Name</label>
                            <input type="text" class="form-control" id="fullName" placeholder="Enter your full name">
                        </div>
                        <div class="form-group">
                            <label for="email">Email Address</label>
                            <input type="email" class="form-control" id="email" placeholder="Enter your email address">
                        </div>
                        <div class="form-group">
                            <label for="Contact Number">Contact Number</label>
                            <input type="Contact Number" class="form-control" id="Contact Number" placeholder="Enter your Contact Number">
                        </div>
                        <div class="form-group">
                            <label for="New Password">New Password</label>
                            <input type="New Password" class="form-control" id="New Password" placeholder="Enter your New Password">
                        </div>
                        <div class="form-group">
                            <label for="Retype Password">Retype Password</label>
                            <input type="Retype Password" class="form-control" id="Retype Password" placeholder="Retype your new password">
                        </div>
                        
                       
                        
                        <button type="submit" class="btn btn-custom btn-block">Update Information</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>
